import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

def find_nearest(a, a0):
    idx = np.abs(a - a0).argmin()
    return a.flat[idx]

def select_state(Z_st, thresh):
    for i in range(Z_st.shape[0]):
        if Z_st[i] > thresh:
            Z_st[i] = 1
        else:
            Z_st[i] = 0                                       
    return Z_st

def corr_indic(trend_period,period_axis,data,thresh):
    nearest = find_nearest(period_axis, trend_period)
    data_T = data.T
    freq_col = data_T.loc[data.T.iloc[:,[-1]].squeeze()==nearest].T.iloc[1:-1,:].values  # index last col
    indic = select_state(np.copy(freq_col),thresh)
    return indic
    
# extract data
data = pd.read_csv("rsq.csv").T
rsq = data.iloc[1:-1,:]
period_axis = data.tail(1).values
period_axis_int= period_axis.astype(int)

inputDF = pd.ExcelFile('Alumin_stocks.xlsx')
tabnames = inputDF.sheet_names
df = inputDF.parse(tabnames[0])

# reset index (and set format) and columns
date = df['DATE']
rsq.index=date
rsq.columns=list(period_axis_int)
rsq.index= rsq.index.strftime('%Y-%m')

# plot coherence map
fig = plt.figure(figsize=(12,12)) 
ax = fig.add_subplot(2,1,1)
sns.heatmap(rsq.T)
ax.set(xlabel='Time', ylabel="Correlated trends time scale")

# plot both stocks on a different plot
stocks = df.set_index('DATE').drop(['INDEX'],axis=1)
stock1 = stocks.iloc[:,0:1]
stock2 = stocks.iloc[:,1:2]

# extract indicators for time trends
trend_period1 = 16
indic1 = corr_indic(trend_period1,period_axis,data,0.7)

trend_period2 = 68
indic2 = corr_indic(trend_period2,period_axis,data,0.7)

fig = plt.figure(figsize=(9.8,5)) 
ax1 = fig.add_subplot(1,1,1)
ax1.set_title("Period of correlation for "+str(trend_period1)+ ' and '+
              str(trend_period2)+' day trend') 

ax1.set_ylim([min(stock1.values)*0.9,max(stock1.values)*1.1])                                    
ax1.fill_between(stock1.index,0,indic1.ravel()*1e5, facecolor='orange', alpha=0.4)
ax1.fill_between(stock1.index,0,indic2.ravel()*1e5, facecolor='brown', alpha=0.4)   

ax1.plot(stocks.index, stock1.values, color='black')

ax2 = ax1.twinx()
ax2.plot(stock2, color='red')
plt.show()

