1. get YOLOv3.weights
2. convert to yolo_weights.h5
3. train model and tune